def convert(pof):
    if pof >= 1:
        return 1
    else:
        return pof